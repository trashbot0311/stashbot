#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Filename: stashbot/create_sqlite.py
"""


import sqlite3
from sqlite3 import Error


conn = sqlite3.connect('stash.sqlite')
c = conn.cursor()


def create_connection(path):
    connection = None
    try:
        connection = sqlite3.connect("stash.sqlite")
        print("create_sqlite Connection to SQLite DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")
    return connection

def execute_query(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")

def execute_read_query(connection, query):
    cursor = connection.cursor()
    result = None
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f'The error {e} has occurred')
        
connection = create_connection("stash.sqlite")

create_pc_wish = """
CREATE TABLE IF NOT EXISTS pc_wish (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    pc_item TEXT NOT NULL
);
"""
execute_query(connection, create_pc_wish)

create_ps_wish = """
CREATE TABLE IF NOT EXISTS ps_wish (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    ps_item TEXT NOT NULL
);
"""
execute_query(connection, create_ps_wish)

create_xb_wish = """
CREATE TABLE IF NOT EXISTS xb_wish (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    xb_item TEXT NOT NULL
);
"""
execute_query(connection, create_xb_wish)

create_pc_inv = """
CREATE TABLE IF NOT EXISTS pc_inv (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    pc_item TEXT NOT NULL
);
"""
execute_query(connection, create_pc_inv)

create_ps_inv = """
CREATE TABLE IF NOT EXISTS ps_inv (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    ps_item TEXT NOT NULL
);
"""
execute_query(connection, create_ps_inv)

create_xb_inv = """
CREATE TABLE IF NOT EXISTS xb_inv (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disc_id INTEGER NOT NULL,
    disc_user TEXT NOT NULL,
    xb_item TEXT NOT NULL
);
"""
execute_query(connection, create_xb_inv)

connection.close()









