#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Filename: stashbot/stashbot.py 
'''

import os
import discord
from discord.ext import commands

#Define bot and set command prefix
client = commands.Bot(command_prefix = '/')

#Confirm connection
@client.event
async def on_ready():
    print('Bot is ready!!')

#Assign discord ID to commands
def is_it_me(ctx):
    #Edit this to your discord ID
    return ctx.author.id == 1234123412341234

#Load cog
@client.command()
@commands.check(is_it_me)
async def load(ctx, extension):
    client.load_extension(f'cogs.{extension}')

#Unload cog
@client.command()
@commands.check(is_it_me)
async def unload(ctx, extension):
    client.unload_extension(f'cogs.{extension}')

#Reload cog
@client.command()
@commands.check(is_it_me)
async def reload(ctx, extension):
    client.unload_extension(f'cogs.{extension}')
    client.load_extension(f'cogs.{extension}')

for filename in os.listdir('./cogs'):
    if filename.endswith('.py'):
        client.load_extension(f'cogs.{filename[:-3]}')

#Enter bots token between quotes
client.run('sdkfjasdlkfjasdkjfsldkjfsdjf')
