#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Filename: stashbot/cogs/usage.py
"""


import discord
from discord.ext import commands

class usage(commands.Cog):
    def __init__(self, client):
        self.client = client

        
    #Create connection
    @commands.Cog.listener()
    async def on_message(self, message):
        channel = message.channel
        #Need to fix check_channel()
        def check_channel():
            if str(channel) == 'pc-stash' or 'ps-stash' or 'xb-stash':
                return True
            else:
                return False
        if message.author == self.client.user:
            return
        #Return message 
        elif check_channel() == True and message.content.startswith('!usage'):
            mention = message.author.mention
            response3 = "!stash item - Add item to your stash.\n!sdel item - Delete item from your stash.\n!mystash - Display top 25 of your stash.\n!mystash item - Search your stash eg: !mystash bol ap\n"
            response2 = "!wish item - Add item to your wishlist.\n!wdel item - Delete item from your wishlist.\n!mywish - Display the top 25 of your wishlist.\n!mywish item - Search your wishlist eg: !mywish bol ap"
            response = "!search item - Search for item eg: !search bol ap ra\n"
            await message.channel.send(f'{mention}:\n**Command Usage:**\n```{response}{response3}{response2}```*Run commands in platform-stash channel.*')
            return
        else:
            return

def setup(client):
    client.add_cog(usage(client))

