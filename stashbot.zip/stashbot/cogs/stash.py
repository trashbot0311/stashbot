#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Filename: stashbot/cogs/stash.py
"""

import sqlite3
import discord
from discord.ext import commands
from sqlite3 import Error

class stash(commands.Cog):
    def __init__(self, client):
        self.client = client

        
    #Create connection
    @commands.Cog.listener()
    async def on_message(self, message):
        channel = message.channel
        #Get search string
        def get_sstring():
            try:
                #convert string to list
                my_input = list(message.content.split(" ", 1))
                #grab last field
                sstring = str(my_input[-1])
                return sstring
            except (IndexError, TypeError, ValueError):
                return None
        def check_channel():
            if str(channel) == 'pc-stash' or 'ps-stash' or 'xb-stash':
                return True
            else:
                return False
        def create_connection(path):
            connection = None
            try:
                connection = sqlite3.connect("stash.sqlite")
                print("Stash Connection to SQLite DB successful")
            except Error as e:
                print(f"The error '{e}' occurred")
            return connection

        def execute_query(connection, query):
            cursor = connection.cursor()
            try:
                cursor.execute(query)
                connection.commit()
                print("Query executed successfully")
            except Error as e:
                print(f"The error '{e}' occurred")

        def execute_read_query(connection, query):
            cursor = connection.cursor()
            result = None
            try:
                cursor.execute(query)
                result = cursor.fetchall()
                return result
            except Error as e:
                print(f'The error {e} has occurred')
        
        
        if message.author == self.client.user:
            return
        #Return message 
        elif check_channel() == True and message.content.startswith('!stash'):
            connection = create_connection("stash.sqlite")
            mention = message.author.mention
            disc_id = message.author.id
            disc_name = message.author.name
            my_item = get_sstring()
            if str(channel) == 'pc-stash':
                if my_item == '!stash':
                    connection.close()
                    return
                    
                else:
                    insert_template = "INSERT INTO pc_inv (disc_id, disc_user, pc_item) VALUES ({0}, '{1}', '{2}');"
                    query_string = insert_template.format(disc_id, disc_name, my_item)
                    execute_query(connection, query_string)
                    await message.channel.send(f'{mention}:\n**You added: ** *{my_item}* ** to your stash.**')
                    connection.close()
            elif str(channel) == 'ps-stash':
                if my_item == '!stash':
                    connection.close()
                    return
                    
                else:
                    insert_template = "INSERT INTO ps_inv (disc_id, disc_user, ps_item) VALUES ({0}, '{1}', '{2}');"
                    query_string = insert_template.format(disc_id, disc_name, my_item)
                    execute_query(connection, query_string)
                    await message.channel.send(f'{mention}:\n**You added: ** *{my_item}* ** to your stash.**')
                    connection.close()
                    return
            elif str(channel) == 'xb-stash':
                if my_item == '!stash':
                    connection.close()
                    return
                    
                else:
                    insert_template = "INSERT INTO xb_inv (disc_id, disc_user, xb_item) VALUES ({0}, '{1}', '{2}');"
                    query_string = insert_template.format(disc_id, disc_name, my_item)
                    execute_query(connection, query_string)
                    await message.channel.send(f'{mention}:\n**You added: ** *{my_item}* ** to your stash.**')
                    connection.close()
                    return
            return
        else:
            return

def setup(client):
    client.add_cog(stash(client))