#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Filename: stashbot/cogs/search.py
"""

import discord
from discord.ext import commands
import sqlite3
from sqlite3 import Error
import re

class search(commands.Cog):
    def __init__(self, client):
        self.client = client
        
    #Create connection
    @commands.Cog.listener()
    async def on_message(self, message):
        channel = message.channel
        def get_sstring():
            try:
                #convert string to list
                my_input = list(message.content.split(" ", 1))
                #grab last field
                sstring = str(my_input[-1])
                return sstring
            except (IndexError, TypeError, ValueError):
                return None
        def create_connection(path):
            connection = None
            try:
                connection = sqlite3.connect("stash.sqlite")
                print("Search Connection to SQLite DB successful")
            except Error as e:
                print(f"The error '{e}' occurred")
            return connection
        def execute_read_query(connection, query):
            cursor = connection.cursor()
            result = None
            try:
                cursor.execute(query)
                result = cursor.fetchall()
                return result
            except Error as e:
                print(f'The error {e} has occurred')
        def check_channel():
            if str(channel) == 'pc-stash' or 'ps-stash' or 'xb-stash':
                return True
            else:
                return False
        def regexp(expr, item):
            reg = re.compile(expr, re.IGNORECASE)
            return reg.search(item) is not None
        def get_regex():
            try:
                reglist = ''
                if ' ' in search_terms:
                    termlist = search_terms.split(" ")
                    firstterm = termlist[0]
                    reglist += str(f'{firstterm}')
                    for term in termlist[1:]:
                        reglist += str(f'(?=.*{term})')
                    return reglist
                else:
                    reglist += str(f'{search_terms}')
                    return reglist
            except (IndexError, TypeError, ValueError):
                return None
        def parse_results():
            try:
                for item in items:
                    result_dict[f'{item[0]}'] += [f'{item[2]}']
                return result_dict
            except (IndexError, TypeError, ValueError):
                return None
        def create_res_dict():
            try:
                result_dict = {}
                for item in items:
                    result_dict[f'{item[0]}'] = [f'{item[1]}']         
                return result_dict
            
            except (IndexError, TypeError, ValueError):
                return None
            
        def get_user_list():
            results = ''
            my_items = list(response[1:])
            counter = 0
            try:
                for item in my_items:
                    if counter < 21:
                        results += str(f'{item[0:]}\n')
                        counter += 1
                return results
            except (IndexError, ValueError, TypeError):
                return None
        
        def my_wish():
            results = ''
            my_items = list(my_wishlist)
            counter = 0
            try:
                for item in my_items:
                    if counter < 16:
                        results += str(f'{item[0]}\n')
                        counter += 1
                return results
            except (IndexError, ValueError, TypeError):
                return None
        if message.author == self.client.user:
            return
        #Return message 
        elif check_channel() == True and message.content.startswith('!search'):
            connection = create_connection("stash.sqlite")
            connection.create_function("REGEXP", 2, regexp)
            mention = message.author.mention
            disc_id = message.author.id
            search_terms = get_sstring()
            if str(channel) == 'pc-stash':
                if str(search_terms) == '!search':
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT disc_id,disc_user,pc_item FROM pc_inv WHERE disc_id != {0} AND pc_item REGEXP '{1}' ORDER BY pc_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    result_dict = create_res_dict()
                    my_results = parse_results()
                    my_keys = list(my_results.keys())
                    
                    for key in my_keys:
                        response = my_results.get(key)
                        user_list = get_user_list()
                        user_key = key
                        wish_query_template = "SELECT pc_item FROM pc_wish WHERE disc_id == {0}"
                        wish_query_string = wish_query_template.format(user_key)
                        my_wishlist = execute_read_query(connection, wish_query_string)
                        wishlist = my_wish()
                        await message.channel.send(f'{mention}:\n**User: {response[0]} has:** *Max 20 results*\n```{user_list}```**Current wishlist:** *Max 15 results.*\n```{wishlist}```')
                    connection.close()
                    return
            elif str(channel) == 'ps-stash':
                if str(search_terms) == '!search':
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT disc_id,disc_user,ps_item FROM ps_inv WHERE disc_id != {0} AND ps_item REGEXP '{1}' ORDER BY ps_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    result_dict = create_res_dict()
                    my_results = parse_results()
                    my_keys = list(my_results.keys())
                    
                    for key in my_keys:
                        response = my_results.get(key)
                        user_list = get_user_list()
                        user_key = key
                        query_template = "SELECT ps_item FROM ps_wish WHERE disc_id == {0}"
                        query_string = query_template.format(user_key)
                        my_wishlist = execute_read_query(connection, query_string)
                        wishlist = my_wish()
                        await message.channel.send(f'{mention}:\n**User: {response[0]} has:** *Max 20 results*\n```{user_list}```**Current wishlist:** *Max 15 results.*\n```{wishlist}```')
                    connection.close()
                    return
            elif str(channel) == 'xb-stash':
                if str(search_terms) == '!search':
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT disc_id,disc_user,xb_item FROM xb_inv WHERE disc_id != {0} AND xb_item REGEXP '{1}' ORDER BY xb_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    result_dict = create_res_dict()
                    my_results = parse_results()
                    my_keys = list(my_results.keys())
                    
                    for key in my_keys:
                        response = my_results.get(key)
                        user_list = get_user_list()
                        user_key = key
                        query_template = "SELECT xb_item FROM xb_wish WHERE disc_id == {0}"
                        query_string = query_template.format(user_key)
                        my_wishlist = execute_read_query(connection, query_string)
                        wishlist = my_wish()
                        await message.channel.send(f'{mention}:\n**User: {response[0]} has:** *Max 20 results*\n```{user_list}```**Current wishlist:** *Max 15 results.*\n```{wishlist}```')
                    connection.close()
                    return
        else:
            return

def setup(client):
    client.add_cog(search(client))