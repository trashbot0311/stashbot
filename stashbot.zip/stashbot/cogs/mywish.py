#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Filename: stashbot/cogs/mywish.py
"""


import sqlite3
import discord
from discord.ext import commands
from sqlite3 import Error
import re

class mywish(commands.Cog):
    def __init__(self, client):
        self.client = client

        
    #Create connection
    @commands.Cog.listener()
    async def on_message(self, message):
        channel = message.channel
        #Get search string
        def get_sstring():
            try:
                #convert string to list
                my_input = list(message.content.split(" ", 1))
                #grab last field
                sstring = str(my_input[-1])
                return sstring
            except (IndexError, TypeError, ValueError):
                return None
        def check_channel():
            if str(channel) == 'pc-stash' or 'ps-stash' or 'xb-stash':
                return True
            else:
                return False
        def create_connection(path):
            connection = None
            try:
                connection = sqlite3.connect("stash.sqlite")
                print("Stash Connection to SQLite DB successful")
            except Error as e:
                print(f"The error '{e}' occurred")
            return connection

        def execute_query(connection, query):
            cursor = connection.cursor()
            try:
                cursor.execute(query)
                connection.commit()
                print("Query executed successfully")
            except Error as e:
                print(f"The error '{e}' occurred")

        def execute_read_query(connection, query):
            cursor = connection.cursor()
            result = None
            try:
                cursor.execute(query)
                result = cursor.fetchall()
                return result
            except Error as e:
                print(f'The error {e} has occurred')
        
        def my_stash():
            results = ''
            my_items = list(items)
            count = 0
            try:
                for item in my_items:
                    if count < 26:
                        results += str(f'{item[0]}\n')
                        count += 1
                return results
            except (IndexError, ValueError, TypeError):
                return None
        
        def regexp(expr, item):
            reg = re.compile(expr, re.IGNORECASE)
            return reg.search(item) is not None
        def get_regex():
            try:
                reglist = ''
                if ' ' in my_item:
                    termlist = my_item.split(" ")
                    firstterm = termlist[0]
                    reglist += str(f'{firstterm}')
                    for term in termlist[1:]:
                        reglist += str(f'(?=.*{term})')
                    return reglist
                else:
                    reglist += str(f'{my_item}')
                    return reglist
            except (IndexError, TypeError, ValueError):
                return None
        
        if message.author == self.client.user:
            return
        #Return message 
        elif check_channel() == True and message.content.startswith('!mywish'):
            connection = create_connection("stash.sqlite")
            connection.create_function("REGEXP", 2, regexp)
            mention = message.author.mention
            disc_id = message.author.id
            my_item = get_sstring()
            if str(channel) == 'pc-stash':
                if my_item == '!mywish':
                    select_template = "SELECT pc_item FROM pc_wish WHERE disc_id == {0} ORDER BY pc_item;"
                    query_string = select_template.format(disc_id)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results. Search your wishlist eg: !mywish bol ap*")
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT pc_item FROM pc_wish WHERE disc_id == {0} AND pc_item REGEXP '{1}' ORDER BY pc_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results.*")
                    connection.close()
                    return
            elif str(channel) == 'ps-stash':
                if my_item == '!mywish':
                    select_template = "SELECT ps_item FROM ps_wish WHERE disc_id == {0} ORDER BY ps_item;"
                    query_string = select_template.format(disc_id)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results. Search your wishlist eg: !mywish bol ap*")
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT ps_item FROM ps_wish WHERE disc_id == {0} AND ps_item REGEXP '{1}' ORDER BY ps_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()  
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results.*")
                    connection.close()
                    return
            elif str(channel) == 'xb-stash':
                if my_item == '!mywish':
                    select_template = "SELECT xb_item FROM xb_wish WHERE disc_id == {0} ORDER BY xb_item;"
                    query_string = select_template.format(disc_id)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results. Search your wishlist eg: !mywish bol ap*")
                    connection.close()
                    return
                else:
                    reglist = get_regex()
                    query_template = "SELECT xb_item FROM xb_wish WHERE disc_id == {0} AND xb_item REGEXP '{1}' ORDER BY xb_item;"
                    query_string = query_template.format(disc_id, reglist)
                    items = execute_read_query(connection, query_string)
                    my_items = my_stash()
                    await message.channel.send(f"{mention}:\n**Your wishlist contains:**\n```{my_items}```*Max 25 results.*")
                    connection.close()
                    return
            else:
                return
def setup(client):
    client.add_cog(mywish(client))